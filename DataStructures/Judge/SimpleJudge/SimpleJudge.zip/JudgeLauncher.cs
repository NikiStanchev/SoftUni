﻿public static class JudgeLauncher
{
    public static void Main()
    {
    }
}

