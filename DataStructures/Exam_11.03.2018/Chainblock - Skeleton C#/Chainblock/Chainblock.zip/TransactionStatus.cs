﻿public enum TransactionStatus
{
    Failed, Successfull, Aborted, Unauthorized
}